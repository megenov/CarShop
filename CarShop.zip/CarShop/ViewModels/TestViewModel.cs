﻿namespace CarShop.ViewModels
{
    public class TestViewModel
    {
        public string Description { get; set; }

        public bool Fixed { get; set; }

        public string IssueId { get; set; }
    }
}